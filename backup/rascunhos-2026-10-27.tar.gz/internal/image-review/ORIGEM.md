# Demonstração AconXego

Prévia local de um produto; não publicada. Execute a partir do repositório:

```sh
python3 -m http.server 4173 --bind 127.0.0.1 --directory demo
```

A página usa somente HTML, CSS e JavaScript, sem dependências. Esta demonstração não implementa o catálogo completo, pagamentos, área de lojistas ou proteção de acesso. Não há preços nem número de WhatsApp configurados.

## Imagem de referência pendente de aprovação

- Página original: https://platform.stlflix.com/pt-BR/product/cross-tray-and-candle-holder
- Nome nos dados públicos: Bandeja Cruz com Porta-Velas.
- Origem exata: https://s3.us-east-2.amazonaws.com/static.stlflix.com/Cross_Tray_and_Candle_Holder1_919355c36f.png
- Identificação: primeiro elemento de `props.pageProps.gallery.data` no JSON público `__NEXT_DATA__` da página.
- Recuperada em 26/10/2026 sem autenticação, sem contornar restrições.
- Arquivo local: assets/bandeja-cruz-original.png. Original preservado sem conversão, recorte ou mudança nas cores.
- A página associa a imagem ao modelo; não comprova que seja fotografia física em vez de renderização. Também não comprova que o produto fabricado pela AconXego terá a mesma aparência.
- A disponibilidade pública não concede licença comercial. Verificar licença/autorização específica para as imagens antes de reutilização comercial ou publicação.
- A conversão WebP e miniaturas definitivas ficam para depois da aprovação. Só há uma imagem na prévia; a janela de detalhes a reutiliza quando aberta.

Não publicar esta demonstração sem autorização do usuário. Não avançar para os demais produtos antes da aprovação.

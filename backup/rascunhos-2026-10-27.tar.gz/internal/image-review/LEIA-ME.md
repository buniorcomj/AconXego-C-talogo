# Conferência interna de imagens — não publicar esta pasta

Nove imagens recuperadas da galeria pública do produto solicitado, em 26/10/2026. As origens e hashes estão em sources.json. Estes arquivos são candidatos para conferência; não estão aprovados para uso comercial. A associação oficial ao modelo não comprova fotografia física nem correspondência com uma peça produzida pela AconXego.

Sirva exclusivamente `demo/` na demonstração. Nunca exponha a raiz do repositório ou `internal/` como diretório público. Esta organização de pastas não implementa autenticação. Não há área administrativa protegida implementada nesta etapa.

A futura administração precisa de autenticação validada no servidor, armazenamento persistente, importação no servidor de URLs permitidas, seleção e autorização de imagens, upload manual e operações de edição, categorias, ocultação/publicação, substituição e exclusão. A API pública deve entregar apenas dados comerciais e imagens autorizadas locais; nunca origens ou metadados internos. O importador deve respeitar restrições de acesso, validar destinos e arquivos e informar falhas sem publicar produtos incompletos.

Não continuar o catálogo completo nem publicar sem aprovação. Após aprovação das imagens e verificação de licença, preparar WebP e miniaturas. O PNG original existente na demonstração é provisório e foi preservado sem alterações. WhatsApp depende do número real da loja, ainda não fornecido.

O teste atual é uma recuperação assistida neste ambiente, não valida a futura importação pela administração na hospedagem.

## Seleção atual

O usuário escolheu a imagem 01 como principal e a 03 como secundária para um único produto, Bandeja Cruz com Porta-Velas, na categoria Artigos Religiosos. As versões WebP em demo/assets foram convertidas sem perdas e verificadas pixel a pixel. A imagem com pomba não integra o catálogo. A autorização para publicação ainda não foi concedida; a licença comercial continua dependendo de verificação.

Para executar a demonstração, sirva somente demo/: `python3 -m http.server 4174 --bind 127.0.0.1 --directory demo`. A porta local não é uma URL de prévia acessível ao usuário nesta interface.
